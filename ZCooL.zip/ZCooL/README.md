# ZeroCooL v1.0

------------------------------------------------------------------------

### :inbox_tray: &nbsp; How to Install &nbsp; :inbox_tray:

Open the terminal and type following commands.

* `pkg update`

* `pkg upgrade`

* `pkg install git`

* `git clone https://github.com/`

* `cd ZCooL`

* `chmod +x install.aex`

* `sh install.aex` if not work than use `./install.aex`

------------------------------------------------------------------------

:warning: &nbsp; **Warning** &nbsp; :warning:

I am ***NOT*** expert, so use this tool at your own risk!
